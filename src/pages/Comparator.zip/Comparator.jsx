// src/pages/Comparator.jsx
import React, { useMemo, useState, useEffect, useCallback, useRef } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";
import Simulator from "../components/Simulator";
import PriceCalculatorCard from "../components/PriceCalculatorCard";
import RecoWeeklyCard from "../components/RecoWeeklyCard";
import {
  buildCandidatePicks,
  pickSafe,
  buildGiftPickBundle,   // ✅ ESTE FALTA
  buildParlay,
  buildValueList,
} from "../lib/fvModel";

const GOLD = "#E6C464";

const API_BASE =
  (import.meta.env.VITE_API_BASE || "").replace(/\/$/, "") ||
  "https://factorvictoria-backend.vercel.app";

/** ✅ Helper: rutas a public que funcionan también en /app (Vite BASE_URL) */
function asset(path) {
  const base = import.meta.env.BASE_URL || "/";
  const clean = String(path || "").replace(/^\/+/, "");
  return `${base}${clean}`;
}

const PLAN_LABELS = {
  basic: { name: "Plan Inicio", price: "$19.990", boost: 20 },
  trimestral: { name: "Plan Goleador", price: "$44.990", boost: 40 },
  anual: { name: "Plan Campeón", price: "$99.990", boost: 100 },
  vitalicio: { name: "Plan Leyenda", price: "$249.990", boost: 200 },
};

/** Fondos (public/) */
const BG_VISITOR = asset("hero-fondo-partidos.png");
const BG_END = asset("hero-12000.png");
const BG_PROFILE_HUD = asset("hero-profile-hud.png");
const BG_DINERO = asset("hero.dinero.png"); // verifica que exista EXACTO en /public
const BG_MANUAL = asset("hero-dorado-estadio.png");
const BG_GRAFICO_DORADO = asset("grafico-dorado.png");
const BG_BIENVENIDO = asset("hero-bienvenido.png");

/** Timezone oficial (igual que Fixtures) */
const APP_TZ = "America/Santiago";

const COMPARATOR_STORAGE_KEY = "fv_comparator_state_v1";
const COMPARATOR_STORAGE_VERSION = 1;

/* --------------------- helpers base --------------------- */
function toOdd(v) {
  if (v == null) return null;
  if (typeof v === "number" && Number.isFinite(v)) return v;

  const s = String(v)
    .trim()
    .toLowerCase()
    .replace(/^x/i, "")     // quita "x1.22"
    .replace(/\s+/g, "")
    .replace(",", ".");     // "1,22" -> "1.22"

  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function normStr(s) {
  return String(s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

// Convierte una racha tipo "W-W-D-W-W" a algo entendible.
// W = Ganado, D = Empate, L = Perdido
function prettyForm(formStr) {
  if (!formStr || typeof formStr !== "string") return "--";
  const parts = formStr
    .split(/\s*[-|\s]\s*/)
    .filter(Boolean)
    .slice(0, 5);
  if (!parts.length) return "--";
  const map = {
    W: { short: "G", icon: "🟢", label: "Ganado" },
    D: { short: "E", icon: "🟡", label: "Empate" },
    L: { short: "P", icon: "🔴", label: "Perdido" },
  };
  return parts
    .map((p) => {
      const k = String(p || "").toUpperCase();
      const m = map[k];
      if (!m) return k;
      return `${m.icon}${m.short}`;
    })
    .join(" ");
}

function hasValidFormStr(s) {
  // Consideramos "racha válida" SOLO si podemos extraer al menos 3 resultados (de los últimos 5)
  // Acepta formatos: "W-D-L-W-W", "G-E-P", "🟢G 🟡E 🔴P", etc.
  if (!s || typeof s !== "string") return false;

  // Normaliza separadores y tokens
  const raw = s
    .replace(/\(|\)|\[|\]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const tokens = raw
    .split(/\s*[-|,\s]\s*/g)
    .map((t) => (t || "").replace(/[^A-Za-z]/g, "").toUpperCase())
    .filter(Boolean)
    .slice(0, 5);

  if (tokens.length < 3) return false;

  // Mapeo: G/E/P (español) -> W/D/L
  const mapped = tokens.map((t) => {
    const c = (t[0] || "").toUpperCase();
    if (c === "G") return "W";
    if (c === "E") return "D";
    if (c === "P") return "L";
    return c;
  });

  const ok = mapped.filter((c) => c === "W" || c === "D" || c === "L");
  return ok.length >= 3;
}


function dataQualityFromLast5(last5) {
  const homeForm = last5?.home?.form || last5?.local?.form || null;
  const awayForm = last5?.away?.form || last5?.visitor?.form || null;
  const hasHome = hasValidFormStr(homeForm);
  const hasAway = hasValidFormStr(awayForm);
  return { hasHome, hasAway, full: hasHome && hasAway };
}


function QualityDot({ dataQuality }) {
  const isFull = dataQuality === "full";
  return (
    <span
      className={`inline-block h-2.5 w-2.5 rounded-full ${
        isFull ? "bg-emerald-400" : "bg-yellow-400"
      }`}
      title={isFull ? "Datos completos" : "Datos parciales"}
    />
  );
}

function DataQualityBadge({ full }) {
  const base = "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] border";
  if (full) {
    return (
      <span className={base + " border-emerald-300/40 bg-emerald-500/10 text-emerald-100"}>
        🟢 Datos completos
      </span>
    );
  }
  return (
    <span className={base + " border-yellow-300/40 bg-yellow-500/10 text-yellow-100"}>
      🟡 Datos parciales
    </span>
  );
}

const FORM_LEGEND = "Leyenda: 🟢G=Ganado, 🟡E=Empate, 🔴P=Perdido";


function includesNorm(haystack, needle) {
  return normStr(haystack).includes(normStr(needle));
}

function toYYYYMMDD(d) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function addDaysYYYYMMDD(baseYYYYMMDD, days) {
  const d = new Date(`${baseYYYYMMDD}T00:00:00`);
  d.setDate(d.getDate() + Number(days || 0));
  return toYYYYMMDD(d);
}

function refereeLevel(avg) {
  if (avg >= 5.5) return "Muy tarjetero";
  if (avg >= 4.5) return "Tarjetero";
  if (avg >= 3.5) return "Normal";
  return "Pocas tarjetas";
}

function getRefereeName(fx) {
  return fx?.fixture?.referee || fx?.referee || "";
}

function getExpectedGoalsFromPack(pack) {
  const model =
    pack?.model ||
    pack?.data?.model ||
    pack?.stats?.model ||
    pack?.payload?.model ||
    null;

  const num = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const home =
    // Backend suele venir con PascalCase
    num(model?.LambdaHome) ??
    num(model?.lambdaHome) ??
    num(model?.homeLambda) ??
    num(model?.home_lambda) ??
    num(model?.lambda_home) ??
    num(model?.xgHome) ??
    num(model?.homeXG) ??
    num(model?.expectedHomeGoals) ??
    num(model?.homeExpectedGoals);

  const away =
    num(model?.LambdaAway) ??
    num(model?.lambdaAway) ??
    num(model?.awayLambda) ??
    num(model?.away_lambda) ??
    num(model?.lambda_away) ??
    num(model?.xgAway) ??
    num(model?.awayXG) ??
    num(model?.expectedAwayGoals) ??
    num(model?.awayExpectedGoals);

  const total =
    num(model?.LambdaTotal) ??
    num(model?.lambdaTotal) ??
    num(model?.lambda_total) ??
    num(model?.xgTotal) ??
    num(model?.expectedGoalsTotal) ??
    (home != null && away != null ? home + away : null);

  if (home == null && away == null && total == null) return null;

  return {
    home,
    away,
    total,
  };
}


/* ------------------- Helpers de fecha/hora (APP_TZ) ------------------- */
function fixtureDateKey(f) {
  const when = f?.fixture?.date || f?.date || "";
  if (!when) return "";
  const d = new Date(when);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: APP_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

function fixtureDateLabel(f) {
  const when = f?.fixture?.date || f?.date || "";
  if (!when) return "";
  const d = new Date(when);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("es-CL", {
    timeZone: APP_TZ,
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(d);
}

function fixtureTimeLabel(f) {
  const when = f?.fixture?.date || f?.date || "";
  if (!when) return "";
  const d = new Date(when);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("es-CL", {
    timeZone: APP_TZ,
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

/* ------------------- País alias ------------------- */
const COUNTRY_ALIAS = {
  chile: "Chile",
  argentina: "Argentina",
  españa: "Spain",
  spain: "Spain",
  inglaterra: "England",
  england: "England",
  francia: "France",
  france: "France",
  brasil: "Brazil",
  brazil: "Brazil",
  alemania: "Germany",
  germany: "Germany",
  italia: "Italy",
  italy: "Italy",
  portugal: "Portugal",
  méxico: "Mexico",
  mexico: "Mexico",
};

function normalizeCountryQuery(q) {
  const key = normStr(q);
  return COUNTRY_ALIAS[key] || null;
}

/* Emojis banderas */
const COUNTRY_FLAG = {
  Chile: "🇨🇱",
  Argentina: "🇦🇷",
  Spain: "🇪🇸",
  England: "🏴",
  France: "🇫🇷",
  Brazil: "🇧🇷",
  Germany: "🇩🇪",
  Italy: "🇮🇹",
  Portugal: "🇵🇹",
  Mexico: "🇲🇽",
  USA: "🇺🇸",
  Colombia: "🇨🇴"
};

/* ------------------- Prioridades / filtro TOP ------------------- */
function countryPriority(countryName) {
  const c = normStr(countryName);
  if (c.includes("england") || c.includes("inglaterra")) return 0;
  if (c.includes("spain") || c.includes("espana") || c.includes("españa")) return 1;
  if (c.includes("france") || c.includes("francia")) return 2;
  if (c.includes("italy") || c.includes("italia")) return 3;
  if (c.includes("germany") || c.includes("alemania")) return 4;

  if (c.includes("argentina")) return 5;
  if (c.includes("chile")) return 6;
  if (c.includes("portugal")) return 7;
  if (c.includes("mexico") || c.includes("méxico")) return 8;
  if (c.includes("usa")) return 9;
  if (c.includes("brazil") || c.includes("brasil")) return 10;
  if (c.includes("colombia")) return 11;

  return 50;
}

function leaguePriority(leagueName) {
  const n = normStr(leagueName);

  // UEFA aqui eliminé, uefa champions league, europa league y conference league

  // Big-5
  if (n.includes("uefa champions league")) return 0;
  if (n.includes("premier league")) return 3;
  if (n.includes("la liga") || n.includes("laliga")) return 4;
  if (n.includes("fifa") || n.includes("world cup")) return 4;
  if (n.includes("serie a")) return 5;
  if (n.includes("bundesliga") && !n.includes("2.")) return 6;
  if (n.includes("ligue 1")) return 7;
  if (n.includes("primera division") || n.includes("primera división") || n.includes("campeonato itau") || n.includes("campeonato itaú")) return 8;
  if (n.includes("copa chile")) return 9;
  if (n.includes("copa de la liga")) return 9;
  if (n.includes("league cup chile")) return 9;
  if (n.includes("copa liga")) return 9;
  // 🌍 Internacional
if (n.includes("fifa series")) return 6;
if (n.includes("friendly") || n.includes("friendlies") || n.includes("amistoso")) return 12;
if (
  n.includes("world cup") ||
  n.includes("wc qualification") ||
  n.includes("qualification") ||
  n.includes("play-off") ||
  n.includes("playoff")
) return 4;

  // América
  if (n.includes("liga mx")) return 10;
  if (n.includes("primera division argentina") || n.includes("liga profesional")) return 11;
  if (n.includes("mls")) return 14;

    // Otras copas (robusto)
if (n.includes("libertadores")) return 15;
if (n.includes("sudamericana")) return 16;

// Copa Alemania suele venir como "dfb pokal" o "dfb-pokal"
if (n.includes("dfb") || n.includes("pokal") || n.includes("copa alemania")) return 17;

// Carabao Cup puede venir como "efl cup" o "carabao"
if (n.includes("carabao") || n.includes("efl cup") || n.includes("league cup")) return 18;

// Copa Argentina
if (n.includes("copa argentina")) return 19;

// Liga Colombia (puede venir como "primera a colombia", "categoría primera a", etc.)
if (n.includes("colombia")) return 20;

// CONCACAF Champions Cup (por tu screenshot de partidos)
if (n.includes("concacaf") && (n.includes("champions") || n.includes("champions cup"))) return 21;

  return 50;
}

function isAllowedCompetition(countryName, leagueName) {
  const c = normStr(countryName);
  const l = normStr(leagueName);
  console.log("LEAGUE ORIGINAL:", leagueName);
  console.log("LEAGUE NORMALIZADA:", l);
  const bannedPatterns = [
    "u23","u22","u21","u20","u19","u18","u17","u16",
    "youth","juvenil","reserves","reserve","b team"," ii",
    "development","professional development",
    "premier league 2","premier league 2 division",
    "women","femenil","femenino","femin","wsl",
    "non league",
    "national league - south",
    "national league - north",
    "efl trophy",
    "serie c","serie d",
    "liga 3",
    "tercera division",
    "tercera division rfef",
    "paulista","paulista a2","baiano","goiano","cearense","pernambucano",
    "matogrossense","maranhense","potiguar","acreano","ofc",
    "ofc champions league","club friendlies",
    "friendlies clubs",

  ];
  if (bannedPatterns.some((p) => l.includes(p))) return false;

  // ✅ Copas internacionales (permitidas)
const intlAllowedIncludes = [
  // copas internacionales
  "libertadores",
  "sudamericana",

  // copas locales
  "copa argentina",
  "copa chile",
  "copa de la liga",
  "copa liga",
  "league cup",
  "copa colombia",

  // 🌍 internacionales (MEJORADO)
  "fifa series",
  "international friendlies",
  "amistoso",

  // mundial y clasificación
  "world cup",
  "fifa world cup",
  "world cup qualification",
  "wc qualification",
  "qualification",
  "qualifiers",

  // playoffs
  "playoff",
  "play-off",
];

if (intlAllowedIncludes.some((k) => l.includes(k))) return true;

  const intlAllowedExact = new Set([
  "uefa champions league",
  "uefa europa league",
  "uefa europa conference league",
  "uefa super cup",
]);

if (intlAllowedExact.has(l)) return true;

  const allowedPairs = [
    { country: "england", league: "premier league" },
    { country: "spain", league: "la liga" },
    { country: "italy", league: "serie a" },
    { country: "germany", league: "bundesliga" },
    { country: "france", league: "ligue 1" },
    { country: "portugal", league: "primeira liga" },
    { country: "mexico", league: "liga mx" },
    { country: "usa", league: "mls" },
    { country: "brazil", league: "serie a" },
    { country: "argentina", league: "primera división argentina" },
    { country: "chile", league: "primera division" },
    { country: "chile", league: "primera división" },
    { country: "chile", league: "primera" },         // opcional si quieres más amplio
    { country: "chile", league: "copa chile" },
    { country: "chile", league: "copa de la liga" },
    { country: "chile", league: "copa liga" },
    { country: "chile", league: "league cup chile" },

  ];

  return allowedPairs.some((p) => c.includes(p.country) && l.includes(normStr(p.league)));
}

/* ------------------- Fixture getters ------------------- */
function getFixtureId(f) {
  return (
    f?.id ||
    f?.fixtureId ||
    f?.fixture_id ||
    f?.fixture?.id ||
    f?.fixture?.fixture_id ||
    `${f?.league?.id || ""}-${f?.timestamp || f?.date || f?.fixture?.date || ""}`
  );
}

function getHomeLogo(f) {
  return f?.teams?.home?.logo || f?.homeLogo || f?.home_logo || null;
}
function getAwayLogo(f) {
  return f?.teams?.away?.logo || f?.awayLogo || f?.away_logo || null;
}

function getLeagueName(f) {
  return f?.league?.name || f?.leagueName || f?.league_name || f?.competition || "Liga desconocida";
}

function getCountryName(f) {
  return f?.league?.country || f?.country || f?.country_name || f?.location || "World";
}

function getHomeName(f) {
  return f?.homeTeam || f?.home_name || f?.localTeam || f?.team_home || f?.teams?.home?.name || "Local";
}

function getAwayName(f) {
  return f?.awayTeam || f?.away_name || f?.visitTeam || f?.team_away || f?.teams?.away?.name || "Visita";
}

function getKickoffTime(f) {
  const iso = f?.date || f?.fixture?.date;
  if (typeof iso === "string" && iso.includes("T")) {
    const d = new Date(iso);
    if (!Number.isNaN(d.getTime())) {
      const hh = String(d.getHours()).padStart(2, "0");
      const mm = String(d.getMinutes()).padStart(2, "0");
      return `${hh}:${mm}`;
    }
  }
  return f?.time || f?.hour || "--:--";
}

/** FUTUROS */
function isFutureFixture(fx) {
  const now = Date.now();

  const ts = fx?.timestamp || fx?.fixture?.timestamp || null;
  if (ts) {
    const ms = Number(ts) * 1000;
    if (!Number.isNaN(ms)) return ms > now;
  }

  const iso = fx?.date || fx?.fixture?.date || null;
  if (iso) {
    const d = new Date(iso);
    if (!Number.isNaN(d.getTime())) return d.getTime() > now;
  }

  return true;
}

/** Filtra juveniles / reservas / femenino */
function isYouthOrWomenOrReserve(fx) {
  const blob = `${getLeagueName(fx)} ${getHomeName(fx)} ${getAwayName(fx)}`.toLowerCase();
  const banned = [
    "u17","u18","u19","u20","u21","u23",
    "reserves","reserve","youth","juvenil","sub-","sub ",
    " women","womens","femen"," fem"," w "," ii"," b ",
    "friendly","amistoso",
  ];
  return banned.some((p) => blob.includes(p));
}

/* --------------------- Plan & Features --------------------- */
function normalizePlanId(raw) {
  const p = String(raw || "").toLowerCase().trim();

  if (["vitalicio", "leyenda", "legend", "lifetime"].some((k) => p.includes(k))) return "vitalicio";
  if (["anual", "campeon", "campeón", "annual", "year"].some((k) => p.includes(k))) return "anual";
  if (["trimestral", "goleador", "tri", "3"].some((k) => p.includes(k))) return "trimestral";
  if (["basic", "mensual", "inicio", "month"].some((k) => p.includes(k))) return "basic";

  return "basic";
}

function normalizeTier(rawTier, rawPlanId) {
  const t = (rawTier || "").toString().trim().toLowerCase();

  // Fuente de verdad: membership.tier (NO usamos plan_id)
  if (["basic", "goleador", "campeon", "leyenda"].includes(t)) return t;

  // Compatibilidad con tiers antiguos si existen registros viejos
  if (t === "vip" || t === "lifetime") return "leyenda";
  if (t === "pro") return "campeon";

  return "basic";
}

function getMaxBoostByTier(tier) {
  // Límites oficiales por membresía
  if (tier === "basic") return 20;      // x10
  if (tier === "goleador") return 40;   // x20
  if (tier === "campeon") return 100;    // x50
  if (tier === "leyenda") return 200;   // x100
  return 20;
}

function getFeaturesByTier(tier) {
  // Permisos/limites por membresía (UI + controles; NO toca fvModel)
  if (tier === "leyenda") {
    return {
      maxBoost: 200,
      maxDays: 10,
      canParlayAuto: true,
      canParlaySelected: true,
      pdfs: true,
      referees: false, // si aún no está listo, déjalo en false
      picks: true,
    };
  }
  if (tier === "campeon") {
    return {
      maxBoost: 100,
      maxDays: 7,
      canParlayAuto: true,
      canParlaySelected: true,
      pdfs: true,
      referees: false,
      picks: true,
    };
  }
  if (tier === "goleador") {
    return {
      maxBoost: 40,
      maxDays: 5,
      canParlayAuto: true,
      canParlaySelected: true,
      pdfs: true,
      referees: false,
      picks: true,
    };
  }
  // basic
  return {
    maxBoost: 20,
    maxDays: 3,
    canParlayAuto: true,
    canParlaySelected: false,
    pdfs: false,
    referees: false,
    picks: false,
  };
}

function getFeaturesByPlanId(planId) {
  const base = { giftPick: true, boosted: true };
  if (planId === "basic") return { ...base, referees: false, scorersValue: false, marketValue: false };
  if (planId === "trimestral") return { ...base, referees: false, scorersValue: false, marketValue: false };
  if (planId === "anual") return { ...base, referees: true, scorersValue: false, marketValue: false };
  return { ...base, referees: true, scorersValue: true, marketValue: true };
}

/* --------------------- UI helpers --------------------- */
function HudCard({
  bg,
  bgColor,
  children,
  className = "",
  style = {},
  overlayVariant = "casillas",
  glow = "gold",
  imgStyle = {},
}) {
  const variants = {
    player: {
      overlays: [
        "linear-gradient(90deg, rgba(2,6,23,0.92) 0%, rgba(2,6,23,0.68) 52%, rgba(2,6,23,0.40) 78%, rgba(2,6,23,0.25) 100%)",
        "radial-gradient(circle at 20% 45%, rgba(16,185,129,0.20), rgba(2,6,23,0) 58%)",
        "radial-gradient(circle at 82% 50%, rgba(230,196,100,0.18), rgba(2,6,23,0) 58%)",
      ],
      imgFilter: "contrast(1.12) saturate(1.08) brightness(0.95)",
    },
    casillas: {
      overlays: [
        "linear-gradient(180deg, rgba(2,6,23,0.88) 0%, rgba(2,6,23,0.62) 38%, rgba(2,6,23,0.86) 100%)",
        "radial-gradient(circle at 18% 30%, rgba(16,185,129,0.18), rgba(2,6,23,0) 60%)",
        "radial-gradient(circle at 85% 60%, rgba(230,196,100,0.14), rgba(2,6,23,0) 60%)",
      ],
      imgFilter: "contrast(1.10) saturate(1.06) brightness(0.96)",
    },
    casillasSharp: {
      overlays: [
        "linear-gradient(180deg, rgba(2,6,23,0.78) 0%, rgba(2,6,23,0.45) 42%, rgba(2,6,23,0.78) 100%)",
        "radial-gradient(circle at 18% 30%, rgba(16,185,129,0.14), rgba(2,6,23,0) 62%)",
        "radial-gradient(circle at 85% 60%, rgba(230,196,100,0.10), rgba(2,6,23,0) 62%)",
      ],
      imgFilter: "contrast(1.18) saturate(1.10) brightness(0.97)",
    },
  };

  const v = variants[overlayVariant] || variants.casillas;
  const [o1, o2, o3] = v.overlays;

  const borderColor = "rgba(255,255,255,0.10)";
  const boxShadow =
    glow === "gold"
      ? [
          "0 0 0 1px rgba(255,255,255,0.03) inset",
          "0 18px 60px rgba(0,0,0,0.55)",
          "0 0 85px rgba(230, 196, 100, 0.30)",
        ].join(", ")
      : ["0 0 0 1px rgba(255,255,255,0.30) inset", "0 18px 60px rgba(0,0,0,0.55)"].join(", ");

  return (
    <div
      className={`relative overflow-hidden rounded-3xl border bg-slate-950/25 backdrop-blur-md ${className}`}
      style={{ borderColor, boxShadow, backgroundColor: bgColor || undefined, ...style }}
    >
      {bg ? (
        <img
          src={bg}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover"
          style={{ filter: v.imgFilter, ...imgStyle }}
        />
      ) : null}

      <div className="absolute inset-0" style={{ background: o1 }} />
      <div className="absolute inset-0" style={{ background: o2 }} />
      <div className="absolute inset-0" style={{ background: o3 }} />

      <div className="relative">{children}</div>
    </div>
  );
}

/* ------------------- Partidazos manuales ------------------- */
const PARTIDAZOS_MANUAL = [
  { date: "2026-01-28", league: "UEFA Champions League", home: "Arsenal", away: "FC kairat" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "paris", away: "newcastle" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "atletico" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "napoli" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "barcelona", away: "København" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "Benfica", away: "madrid" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "Manchester city", away: "galatasaray" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "borusia", away: "inter" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "club brugge", away: "marseille" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "atalanta" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "Pafos" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "Juventus" },
  { date: "2026-01-28", league: "UEFA Champions League", home: "Liverpool", away: "qarabag fk" },

  // ✅ IDs estables
  { fixtureId: 1504664 },
  { fixtureId: 1451134 },
  { fixtureId: 1451132 },
  { fixtureId: 1451161 }, // fc barcelona champions 28-01-2026
  { fixtureId: 1451162 }, // Benfica vs madrid  28-01-2026
];

function picksFromFixturesComparator(fixtures) {
  const out = [];
  const used = new Set();

  for (const pick of PARTIDAZOS_MANUAL) {
    const p = pick || {};
    const wantedId = p.fixtureId;
    let found = null;

    if (wantedId) {
      found = fixtures.find((f) => String(getFixtureId(f)) === String(wantedId));
    } else {
      found = fixtures.find((f) => {
        const dKey = fixtureDateKey(f);
        const league = getLeagueName(f);
        const home = getHomeName(f);
        const away = getAwayName(f);

        if (p.date && dKey !== String(p.date)) return false;
        if (p.league && !includesNorm(league || "", p.league)) return false;
        if (p.home && !includesNorm(home || "", p.home)) return false;
        if (p.away && !includesNorm(away || "", p.away)) return false;

        return true;
      });
    }

    if (found) {
      const id = getFixtureId(found);
      if (!used.has(id)) {
        used.add(id);
        out.push(found);
      }
    }
  }

  return out;
}

/** ✅ Wrapper layout */
function PageShell({ children }) {
  return (
    <div className="relative max-w-5xl mx-auto px-4 pb-20">
      <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
        <div
          className="absolute -top-44 left-1/2 -translate-x-1/2 h-[640px] w-[640px] rounded-full blur-3xl opacity-20"
          style={{
            background: "radial-gradient(circle at center, rgba(16,185,129,0.55), rgba(15,23,42,0) 60%)",
          }}
        />
        <div
          className="absolute -top-52 right-[-140px] h-[560px] w-[560px] rounded-full blur-3xl opacity-16"
          style={{
            background: "radial-gradient(circle at center, rgba(230,196,100,0.45), rgba(15,23,42,0) 62%)",
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.10]"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgba(255,255,255,0.10) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.10) 1px, transparent 1px)",
            backgroundSize: "56px 56px",
            maskImage: "radial-gradient(circle at 50% 18%, black 0%, transparent 70%)",
            WebkitMaskImage: "radial-gradient(circle at 50% 18%, black 0%, transparent 70%)",
          }}
        />
      </div>

      {children}
    </div>
  );
}

/* ------------------- Visitante ------------------- */
function VisitorBanner() {
  const nav = useNavigate();
  const goPlans = () => window.location.assign("/#planes");

  return (
    <HudCard bg={BG_VISITOR} overlayVariant="player" className="mt-4" glow="gold">
      <div className="p-5 md:p-7">
        <div className="text-xs tracking-wide text-emerald-200/90 font-semibold">Modo visitante</div>

        <div className="mt-1 text-lg md:text-xl font-bold text-slate-100">
          Para crear cuotas x10, x20, x50 y x100 necesitas membresía
        </div>

        <div className="mt-2 text-sm text-slate-200 max-w-2xl">
          Activa tu plan para desbloquear el comparador profesional (cuotas potenciadas, combinada automática y módulos
          premium). Si ya tienes membresía, inicia sesión.
        </div>

        <div className="mt-4 flex flex-col sm:flex-row gap-2">
          <button
            type="button"
            onClick={goPlans}
            className="w-full sm:w-auto px-6 py-3 rounded-full text-sm font-bold"
            style={{ backgroundColor: GOLD, color: "#0f172a", boxShadow: "0 0 28px rgba(230,196,100,0.24)" }}
          >
            Comprar membresía
          </button>

          <button
            type="button"
            onClick={() => nav("/login")}
            className="w-full sm:w-auto px-6 py-3 rounded-full text-sm font-semibold border border-white/15 bg-white/5 hover:bg-white/10 transition"
          >
            Iniciar sesión
          </button>
        </div>
      </div>
    </HudCard>
  );
}

function LockedPlanCard({ title, price, bullets, href }) {
  return (
    <div className="relative rounded-2xl bg-white/5 border border-white/10 p-4 md:p-5 overflow-hidden">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm md:text-base font-semibold text-emerald-400">{title}</div>
          <div className="mt-1 inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-white/5 border border-white/10 text-slate-200">
            {price}
          </div>
        </div>
        <div className="text-xs text-slate-400">Bloqueado por plan</div>
      </div>

      <ul className="mt-3 space-y-1 text-xs text-slate-300">
        {bullets.map((b) => (
          <li key={b} className="flex gap-2">
            <span className="mt-1 w-1.5 h-1.5 rounded-full bg-emerald-400/80" />
            <span>{b}</span>
          </li>
        ))}
      </ul>

      <a
        href={href}
        className="inline-flex mt-4 items-center justify-center rounded-xl px-3 py-2 text-xs font-semibold border border-yellow-400/60 bg-yellow-500/10 text-yellow-200"
      >
        Ver este plan
      </a>
    </div>
  );
}

function VisitorPlansGrid() {
  return (
    <section className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
      <LockedPlanCard
        title="Plan Mensual"
        price="$19.990 · x10"
        href="/#plan-mensual"
        bullets={["Cuotas potenciadas hasta x10", "Cuota de regalo", "Acceso a herramientas base"]}
      />
      <LockedPlanCard
        title="Plan Trimestral"
        price="$44.990 · x20"
        href="/#plan-trimestral"
        bullets={["Cuotas potenciadas hasta x20", "Mejor filtrado de partidos", "Más herramientas para combinadas"]}
      />
      <LockedPlanCard
        title="Plan Anual"
        price="$99.990 · x50"
        href="/#plan-anual"
        bullets={["Cuotas potenciadas hasta x50", "Módulo árbitros tarjeteros", "Top remates (hasta 5)"]}
      />
      <LockedPlanCard
        title="Plan Vitalicio"
        price="$249.990 · x100"
        href="/#plan-vitalicio"
        bullets={["Cuotas potenciadas hasta x100", "Value / desfase del mercado (VIP)", "Goleadores + remates (Top 10)"]}
      />
    </section>
  );
}

function VisitorEndingHero() {
  return (
    <div className="mt-6 rounded-3xl border border-white/10 overflow-hidden bg-white/5">
      <div className="w-full h-[260px] md:h-[360px] lg:h-[420px] bg-slate-950 overflow-hidden">
        <img src={BG_END} alt="Factor Victoria" className="w-full h-full object-cover object-center" />
      </div>
      <div className="p-4 text-center text-xs text-slate-500">© {new Date().getFullYear()} Factor Victoria</div>
    </div>
  );
}

/* --------------------- componente principal --------------------- */
function WelcomeProCard({ planInfo }) {
  return (
    <HudCard bg={BG_BIENVENIDO} overlayVariant="casillas" className="mt-4" glow="gold">
      <div className="p-5 md:p-6">
        <div className="text-emerald-200/90 text-xs font-semibold tracking-wide">Bienvenido a Factor Victoria PRO</div>
        <div className="mt-1 text-xl md:text-2xl font-bold text-slate-100">{planInfo.name} Activo</div>

        <div className="mt-3 text-sm text-slate-300 leading-relaxed">
          Este es el punto donde apostar deja de ser intuición y pasa a ser <span className="font-semibold">estrategia</span>.
        </div>
      </div>
    </HudCard>
  );
}

/* ------------------- FixtureCard (compact) ------------------- */
function FixtureCardCompact({ fx, isSelected, onToggle, onLoadOdds, onLoadStats, fvPack, last5, fvLoading, fvErr }) {
  const id = getFixtureId(fx);

  const league = getLeagueName(fx);
  const countryName = getCountryName(fx);
  const flagEmoji = COUNTRY_FLAG[countryName] || (countryName === "World" ? "🌍" : "🏳️");
  const home = getHomeName(fx);
  const away = getAwayName(fx);
  const date = fixtureDateLabel(fx) || fixtureDateKey(fx);
  const time = fixtureTimeLabel(fx) || getKickoffTime(fx);
  const whenLabel = date ? `${date} · ${time || "--:--"}` : time || "--:--";

  const homeLogo = getHomeLogo(fx);
  const awayLogo = getAwayLogo(fx);

  const [open, setOpen] = useState(false);

  const borderColor = "rgba(255,255,255,0.08)";
  const boxShadow = "0 0 0 1px rgba(255,255,255,0.03) inset, 0 0 26px rgba(230,196,100,0.12)";

  return (
    <div className="rounded-2xl border bg-slate-950/25 backdrop-blur-md overflow-hidden" style={{ borderColor, boxShadow }}>
      <div className="p-3 md:p-4 flex flex-col md:flex-row md:items-center gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 min-w-0">
              {homeLogo ? (
                <img src={homeLogo} alt={home} className="w-7 h-7 rounded-full bg-white/5 object-contain" />
              ) : (
                <div className="w-7 h-7 rounded-full bg-white/5" />
              )}
              <div className="truncate text-slate-100 font-semibold">{home}</div>
            </div>

            <div className="text-slate-400 font-semibold">vs</div>

            <div className="flex items-center gap-2 min-w-0">
              {awayLogo ? (
                <img src={awayLogo} alt={away} className="w-7 h-7 rounded-full bg-white/5 object-contain" />
              ) : (
                <div className="w-7 h-7 rounded-full bg-white/5" />
              )}
              <div className="truncate text-slate-100 font-semibold">{away}</div>
            </div>
          </div>

          <div className="mt-1 text-xs text-slate-300 flex flex-wrap items-center gap-2">
            <span className="text-base leading-none">{flagEmoji}</span>
            <span className="font-medium">{countryName}</span>
            <span className="text-slate-500">·</span>
            <span className="truncate">{league}</span>
            <span className="text-slate-500">·</span>
            <span className="font-semibold text-slate-200">{whenLabel}</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <button
            type="button"
            onClick={() => {
              setOpen((v) => {
                const next = !v;
                if (next) onLoadStats?.(id);
                return next;
              });
            }}
            className="rounded-full px-4 py-2 text-xs font-semibold border border-white/15 bg-white/5 hover:bg-white/10 transition text-slate-100"
          >
            {open ? "Ocultar estadísticas" : "Ver estadísticas"}
          </button>

          <button
            type="button"
            onClick={() => {
              onToggle?.(id);
              onLoadOdds?.(id);
            }}
            className="rounded-full px-4 py-2 text-xs font-bold"
            style={{
              backgroundColor: isSelected ? "rgba(16,185,129,0.18)" : "rgba(56,189,248,0.18)",
              border: "1px solid rgba(255,255,255,0.12)",
              color: isSelected ? "rgba(167,243,208,0.95)" : "rgba(186,230,253,0.95)",
            }}
          >
            {isSelected ? "Quitar" : "Añadir a combinada"}
          </button>
        </div>
      </div>

      {open ? (
        <div className="px-3 md:px-4 pb-3 md:pb-4">
          <div className="rounded-xl border border-white/10 bg-slate-950/30 p-3 text-[11px] text-slate-300">
            {fvLoading ? (
              <div className="text-[11px] text-slate-300">Cargando estadísticas reales…</div>
            ) : fvPack ? (
              <div className="text-[11px] text-slate-300 leading-relaxed">
                <div className="flex flex-wrap gap-x-4 gap-y-1">
<div>
  <span className="text-slate-400">Racha (últ.5) local:</span>{" "}
  <span className="text-slate-100 font-semibold">{last5?.home?.form || "--"}</span>
  {last5?.home?.form ? (
    <span className="ml-2 text-slate-300">({prettyForm(last5.home.form)})</span>
  ) : null}
</div>

<div>
  <span className="text-slate-400">Racha (últ.5) visita:</span>{" "}
  <span className="text-slate-100 font-semibold">{last5?.away?.form || "--"}</span>
  {last5?.away?.form ? (
    <span className="ml-2 text-slate-300">({prettyForm(last5.away.form)})</span>
  ) : null}
</div>

<div>
  <span className="text-slate-400">Goles (últ.5) local:</span>{" "}
  <span className="text-slate-100 font-semibold">
    {last5?.home?.gf ?? "--"} / {last5?.home?.ga ?? "--"}
  </span>
</div>

<div>
  <span className="text-slate-400">Goles (últ.5) visita:</span>{" "}
  <span className="text-slate-100 font-semibold">
    {last5?.away?.gf ?? "--"} / {last5?.away?.ga ?? "--"}
  </span>
</div><div>
  <span className="text-slate-400">Goles esperados (FV):</span>{" "}
  <span className="text-emerald-200 font-semibold">
    {(() => {
      const xg = getExpectedGoalsFromPack(fvPack);
      if (!xg) return "--";

      // si tenemos home/away, mostramos desglosado
      if (xg.home != null && xg.away != null) {
        const total = (xg.total != null ? xg.total : xg.home + xg.away);
        return `${xg.home.toFixed(2)} + ${xg.away.toFixed(2)} = ${total.toFixed(2)}`;
      }

      // fallback a total
      if (xg.total != null) return xg.total.toFixed(2);

      return "--";
    })()}
  </span>
</div>

                </div>
                {(last5?.home?.form || last5?.away?.form) ? (
                  <div className="mt-1 text-[10px] text-slate-400">{FORM_LEGEND}</div>
                ) : null}

                {/* fixtureId oculto (debug) */}
              </div>
            ) : (
              <div className="text-[11px] text-slate-400">
                Sin estadísticas aún (o no disponibles). Igual podemos estimar con heurísticas.
                {/* fixtureId oculto (debug) */}
              </div>
            )}

            {fvErr ? <div className="mt-2 text-amber-300">Error stats: {fvErr}</div> : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ------------------- FeatureCard ------------------- */
function FeatureCard({ title, badge, children, locked, lockText, bg }) {
  return (
    <HudCard bg={bg || BG_GRAFICO_DORADO} overlayVariant="casillas" glow="gold" className="overflow-hidden">
      <div className="relative p-4 md:p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-sm md:text-base font-semibold text-emerald-400">{title}</div>
            {badge ? (
              <div className="mt-1 inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-white/5 border border-white/10 text-slate-200">
                {badge}
              </div>
            ) : null}
          </div>
        </div>

        <div className="mt-3">{children}</div>

        {locked ? (
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-[2px] flex items-center justify-center p-4">
            <div className="max-w-sm text-center">
              <div className="text-sm font-semibold text-slate-50">Bloqueado por plan</div>
              <div className="mt-1 text-xs text-slate-300">{lockText || "Disponible en planes superiores."}</div>
              <Link
                to="/#planes"
                className="inline-flex mt-3 items-center justify-center rounded-xl px-3 py-2 text-xs font-semibold border border-yellow-400/60 bg-yellow-500/10 text-yellow-200"
              >
                Ver planes
              </Link>
            </div>
          </div>
        ) : null}
      </div>
    </HudCard>
  );
}

/* ------------------- Manual Picks ------------------- */
function ManualPicksSection() {
  const singles = [
    { label: "Chile v/s C.verde +1.5 goles", odd: 1.60, note: "Alta probabilidad" },
    { label: "España v/s Servia +1.5 goles", odd: 1.18, note: "Conservador" },
  ];

  const combos = [
    { label: "Inglaterra v/s Uruguay +1.5 goles", odd: 1.40, note: "Cuota media" },
    { label: "Dani Olmo +0.5 remates al arco", odd: 1.30, note: "Más riesgo" },
  ];

  const players = [
    { label: "Cole Palmer +0.5 remates al arco", odd: 1.60, note: "Si es titular" },
    { label: "Kilyan Mbappé +0.5 goles ", odd: 1.98, note: "Tendencia" },
  ];

  function Card({ title, items }) {
    return (
      <div className="rounded-2xl border border-white/10 bg-slate-950/30 p-4 md:p-5">
        <div className="flex items-center justify-between gap-3">
          <div className="text-sm font-semibold text-slate-100">{title}</div>
          <div className="text-xs font-semibold text-emerald-200">Cuotas exclusivas para miembros</div>
        </div>

        <div className="mt-3 space-y-2">
          {items.map((x) => (
            <div
              key={x.label}
              className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-slate-950/40 px-3 py-2"
            >
              <div className="min-w-0">
                <div className="text-sm text-slate-100 font-semibold truncate">{x.label}</div>
                {x.note ? <div className="text-[11px] text-emerald-300/80">{x.note}</div> : null}
              </div>
              <div className="text-sm font-bold text-emerald-200">x{Number(x.odd).toFixed(2)}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <section className="mt-6">
      <HudCard bg={BG_MANUAL} overlayVariant="casillas" glow="gold" className="overflow-hidden">
        <div className="p-4 md:p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card title="Partidos únicos" items={singles} />
            <Card title="Combinadas" items={combos} />
            <Card title="Jugadores" items={players} />
          </div>
        </div>
      </HudCard>
    </section>
  );
}
function buildBoostedParlayLocal({ candidatesByFixture, target, cap, minProb = 0.52, maxLegs = 12 }) {
  const fixtureIds = Object.keys(candidatesByFixture || {});
  if (!fixtureIds.length) return null;

function localPenalty(label, odd) {
  const s = String(label || "").toLowerCase();
  let p = 1;

  // penaliza cuotas ultra bajas (relleno típico)
  if (odd != null && odd <= 1.08) p *= 0.55;

  // penaliza handicaps “de regalo” repetitivos (+3/+4/+5)
  if (s.includes("hándicap") || s.includes("handicap")) {
    if (s.includes("+3") || s.includes("+4") || s.includes("+5")) p *= 0.55;
  }

  if (s.includes("2.5") && (s.includes("over") || s.includes("under") || s.includes("goles"))) p *= 0.82;
  if ((s.includes("over") || s.includes("under")) && !s.includes("1x") && !s.includes("x2")) p *= 0.92;
  if (s.includes("btts") || s.includes("both teams") || s.includes("ambos")) p *= 0.95;

  return p;
}

  // Para cada fixture, nos quedamos con candidatos "usables" (odd>1 y prob decente)
  const perFx = fixtureIds.map((fxId) => {
    const arr = (candidatesByFixture[fxId] || [])
      .map((c) => {
        const odd =
          toOdd(c.usedOddDisplay) ??
          toOdd(c.usedOdd) ??
          toOdd(c.marketOdd) ??
          toOdd(c.fvOdd);

        const prob = Number(c?.prob);
        const probOk = Number.isFinite(prob) ? prob : null;

        return { ...c, _fxId: fxId, _odd: odd, _prob: probOk };
      })
      .filter((c) => c._odd != null && c._odd > 1.01)
      .filter((c) => c._prob == null || c._prob >= minProb)
      .map((c) => {
        const pen = localPenalty(c.label || c.pick, c._odd);
        return { ...c, _penalty: pen, _scoreOdd: (c._odd || 0) * pen };
      })
      .sort((a, b) => (b._scoreOdd || 0) - (a._scoreOdd || 0)); // prioriza odds (con penalización)

    return { fxId, candidates: arr };
  });

  // Si no hay candidatos usables, no se puede
  if (!perFx.some((x) => x.candidates.length)) return null;

  // Máximo alcanzable: producto del mejor odd por fixture (limitado a maxLegs)
  const bestOdds = perFx
    .map((x) => x.candidates[0]?._odd)
    .filter((x) => x != null)
    .sort((a, b) => b - a)
    .slice(0, maxLegs);

  const maxPossible = bestOdds.reduce((acc, o) => acc * o, 1);
  if (maxPossible < Math.min(target * 0.98, cap * 0.98)) {
    // No alcanza el target ni siquiera con los mejores odds
    return null;
  }

  // Greedy: vamos agregando la mejor pieza que más acerque al target sin pasarnos absurdamente
  let product = 1;
  const usedFx = new Set();
  const legs = [];

  // Diversidad: evitar abuso de Hándicap +3 como 'relleno'
  let hcap3Count = 0;
  let hcap2Count = 0;
  const _labelOf = (c) => String(c?.label || c?.pick || "");
  const _isHandicapPlus = (c, n) => {
    const s = _labelOf(c).toLowerCase();
    return (s.includes("hándicap") || s.includes("handicap")) && s.includes(`+${n}`);
  };

  while (legs.length < maxLegs && product < target * 0.98) {
    let best = null;

    for (const fx of perFx) {
      if (usedFx.has(fx.fxId)) continue;
      if (!fx.candidates.length) continue;

      // probamos top 5 de cada fixture (suficiente)
      const top = fx.candidates.slice(0, 5);

      for (const c of top) {
        // Cap: máx 3 picks de Hándicap +3 por parlay.
        // Y para permitir 3×(+3), exigimos que exista al menos 1×(+2) en el mismo parlay.
        if (_isHandicapPlus(c, 3)) {
          if (hcap3Count >= 3) continue;
          if (hcap3Count >= 2 && hcap2Count < 1) continue;
        }
        const next = product * c._odd;

        // score: preferimos acercarnos al target; si lo sobrepasa un poco no importa
        const dist = Math.abs(Math.log(target) - Math.log(next));
        const probBonus = c._prob != null ? (c._prob - 0.5) : 0;
        const pen = c._penalty ?? 1;
        const score = -dist + probBonus * 0.35 - (1 - pen) * 0.8; // penaliza overs repetidos

        if (!best || score > best.score) best = { c, score, next };
      }
    }

    if (!best) break;
    legs.push(best.c);
    // actualizar conteo de handicaps (+2/+3)
    if (_isHandicapPlus(best.c, 3)) hcap3Count += 1;
    if (_isHandicapPlus(best.c, 2)) hcap2Count += 1;
    usedFx.add(best.c._fxId);
    product = best.next;
  }

  if (!legs.length) return null;

  const finalOdd = Number(product.toFixed(2));
  const impliedProb = Number(((1 / finalOdd) * 100).toFixed(1));
  const reachedTarget = finalOdd >= target * 0.98;

  return {
    target,
    cap,
    games: legs.length,
    finalOdd,
    impliedProb,
    reachedTarget,
    legs: legs.map((c) => ({
      fixtureId: c._fxId,
      label: c.label || c.pick || "Pick",
      home: c.home,
      away: c.away,
      prob: c.prob,
      fvOdd: c.fvOdd,
      marketOdd: c.marketOdd,
      usedOdd: c.usedOdd,
      usedOddDisplay: c.usedOddDisplay ?? c.usedOdd ?? c.marketOdd ?? c.fvOdd,
    })),
  };
}

export default function Comparator() {
  const { isLoggedIn, user } = useAuth();
  const [searchParams] = useSearchParams();

  // Launch safeguard: hide unfinished modules for now
  const ENABLE_REFEREES = false;
  const ENABLE_SCORERS = false;

  const today = useMemo(() => new Date(), []);
  const [from, setFrom] = useState(toYYYYMMDD(today));
  const [to, setTo] = useState(toYYYYMMDD(today));
  const [q, setQ] = useState("");

  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");

  const [loading, setLoading] = useState(false);
  const [generatedOk, setGeneratedOk] = useState(false);
  const okTimerRef = useRef(null);

  useEffect(() => {
    return () => {
      if (okTimerRef.current) clearTimeout(okTimerRef.current);
    };
  }, []);

  const [fixtures, setFixtures] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);

  // ✅ Partidazos semanal
  const [weeklyLoading, setWeeklyLoading] = useState(false);
  const [weeklyErr, setWeeklyErr] = useState("");
  const [weeklyFixtures, setWeeklyFixtures] = useState([]);

  // ✅ Multi-país
  const [selectedCountries, setSelectedCountries] = useState([]);

  // odds cache
  const [oddsByFixture, setOddsByFixture] = useState({});
  const oddsRef = useRef({});

  // FV pack cache (stats + modelo + markets)
  const [fvPackByFixture, setFvPackByFixture] = useState({});
  const [fvLoadingByFixture, setFvLoadingByFixture] = useState({});
  const fvRef = useRef({});
  const [fvErrByFixture, setFvErrByFixture] = useState({});

  // Membership/tier (fuente de verdad: backend /api/membership)
  const [membershipInfo, setMembershipInfo] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function loadMembership() {
      if (!isLoggedIn) return;
      const email = user?.email;
      if (!email) return;
      try {
        const res = await fetch(
          `${API_BASE}/api/membership?email=${encodeURIComponent(email)}`
        );
        const data = await res.json();
        if (!cancelled && data?.ok) {
          setMembershipInfo(data.membership || null);
        }
      } catch {
        // silencio: si falla, seguimos con lo que haya en el user
      }
    }
    loadMembership();
    return () => {
      cancelled = true;
    };
  }, [isLoggedIn, user?.email]);

  const planId = useMemo(() => {
    return normalizePlanId(
      membershipInfo?.plan_id ||
        membershipInfo?.planId ||
        user?.planId ||
        user?.plan_id ||
        "basic"
    );
  }, [membershipInfo, user]);

  const tier = useMemo(() => {
    return normalizeTier(membershipInfo?.tier || user?.tier, planId);
  }, [membershipInfo, user, planId]);

  const maxBoost = useMemo(() => getMaxBoostByTier(tier), [tier]);

  const planInfo = useMemo(() => {
    const label =
      tier === "leyenda"
        ? "LEYENDA"
        : tier === "campeon"
        ? "CAMPEÓN"
        : tier === "goleador"
        ? "GOLEADOR"
        : "INICIO";
    return {
      label,
      boost: maxBoost,
    };
  }, [tier, maxBoost]);

const features = useMemo(() => {
    return {
      giftPick: true,
      boosted: true,
      marketValue: tier === "leyenda",
      scorersValue: tier === "leyenda",
    };
  }, [tier]);

const canReferees = !!features?.referees; // ✅ AQUÍ (dentro del componente)

  // combinadas
  const [parlayResult, setParlayResult] = useState(null);
  const [parlayError, setParlayError] = useState("");
  const [fvOutput, setFvOutput] = useState(null);

  // referees module
  const [refData, setRefData] = useState(null);
  const [refLoading, setRefLoading] = useState(false);
  const [refErr, setRefErr] = useState("");


  // -------------------- Persist Comparator state across tab navigation --------------------
  const _restoredRef = useRef(false);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(COMPARATOR_STORAGE_KEY);
      if (!raw) return;
      const st = JSON.parse(raw);
      if (!st || st.v !== COMPARATOR_STORAGE_VERSION) return;

      if (st.from) setFrom(st.from);
      if (st.to) setTo(st.to);
      if (typeof st.q === "string") setQ(st.q);

      if (Array.isArray(st.selectedIds)) setSelectedIds(st.selectedIds);
      if (Array.isArray(st.selectedCountries)) setSelectedCountries(st.selectedCountries);

      if (Array.isArray(st.fixtures)) setFixtures(st.fixtures);
      if (Array.isArray(st.weeklyFixtures)) setWeeklyFixtures(st.weeklyFixtures);

      if (st.oddsByFixture && typeof st.oddsByFixture === "object") setOddsByFixture(st.oddsByFixture);
      if (st.fvPackByFixture && typeof st.fvPackByFixture === "object") setFvPackByFixture(st.fvPackByFixture);

      if (st.fvOutput) setFvOutput(st.fvOutput);
      if (st.parlayResult) setParlayResult(st.parlayResult);
      if (typeof st.generatedOk === "boolean") setGeneratedOk(st.generatedOk);

      _restoredRef.current = true;
    } catch (e) {
      // ignore corrupted cache
    }
  }, []);

  useEffect(() => {
    if (!_restoredRef.current) return;

    const payload = {
      v: COMPARATOR_STORAGE_VERSION,
      ts: Date.now(),
      from,
      to,
      q,
      selectedIds,
      selectedCountries,
      fixtures,
      weeklyFixtures,
      oddsByFixture,
      fvPackByFixture,
      fvOutput,
      parlayResult,
      generatedOk,
    };

    const t = setTimeout(() => {
      try {
        sessionStorage.setItem(COMPARATOR_STORAGE_KEY, JSON.stringify(payload));
      } catch {
        // storage full or blocked
      }
    }, 250);

    return () => clearTimeout(t);
  }, [
    from,
    to,
    q,
    selectedIds,
    selectedCountries,
    fixtures,
    weeklyFixtures,
    oddsByFixture,
    fvPackByFixture,
    fvOutput,
    parlayResult,
    generatedOk,
  ]);

  useEffect(() => {
    const urlDate = searchParams.get("date");
    const urlQ = searchParams.get("q");
    if (urlDate) {
      setFrom(urlDate);
      setTo(urlDate);
    }
    if (urlQ) setQ(urlQ);
  }, [searchParams]);

  const quickCountries = ["Chile", "España", "Portugal", "Italia", "Alemania", "Argentina", "Inglaterra", "Francia", "Brasil", "México"];

  function toggleCountryChip(countryEs) {
    const en = normalizeCountryQuery(countryEs) || countryEs;
    setSelectedCountries((prev) => (prev.includes(en) ? prev.filter((x) => x !== en) : [...prev, en]));
  }

  // ✅ cargar weekly al montar
  useEffect(() => {
    let alive = true;

    async function loadWeekly() {
      setWeeklyErr("");
      setWeeklyLoading(true);

      try {
        const fromW = toYYYYMMDD(new Date());
        const toW = addDaysYYYYMMDD(fromW, 7);

        const params = new URLSearchParams();
        params.set("from", fromW);
        params.set("to", toW);

        const res = await fetch(`${API_BASE}/api/fixtures?${params.toString()}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();
    
if (!window.__fvpackOnce) {
  window.__fvpackOnce = true;
  console.log("[FVPACK sample]", data);
  console.log("[FVPACK keys]", Object.keys(data || {}));
}

// Normaliza respuesta (mantén fallback a data.fixtures)
const itemsRaw =
  (Array.isArray(data?.items) && data.items) ||
  (Array.isArray(data?.response) && data.response) ||
  (Array.isArray(data?.fixtures) && data.fixtures) ||
  [];

let items = itemsRaw;

const base = items
  .filter(isFutureFixture)
  .filter((fx) => !isYouthOrWomenOrReserve(fx));



        const filteredTop = base.filter((fx) => isAllowedCompetition(getCountryName(fx), getLeagueName(fx)));

        const sorted = [...filteredTop].sort((a, b) => {
          const da = new Date(a?.fixture?.date || a?.date || 0).getTime();
          const db = new Date(b?.fixture?.date || b?.date || 0).getTime();
          if (da !== db) return da - db;

          const pla = leaguePriority(getLeagueName(a));
          const plb = leaguePriority(getLeagueName(b));
          if (pla !== plb) return pla - plb;

          const ca = countryPriority(getCountryName(a));
          const cb = countryPriority(getCountryName(b));
          if (ca !== cb) return ca - cb;

          const ta = fixtureTimeLabel(a) || getKickoffTime(a) || "";
          const tb = fixtureTimeLabel(b) || getKickoffTime(b) || "";
          return ta.localeCompare(tb);
        });

        if (!alive) return;
        setWeeklyFixtures(sorted.slice(0, 220));
      } catch (e) {
        if (!alive) return;
        setWeeklyErr(String(e?.message || e));
      } finally {
        if (!alive) return;
        setWeeklyLoading(false);
      }
    }

    loadWeekly();
    return () => {
      alive = false;
    };
  }, []);

  function toggleFixtureSelection(id) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  const selectedCount = selectedIds.length;

  // odds cache
const ensureOdds = useCallback(
  async (fixtureId) => {
    if (!fixtureId) return;

    const ODDS_TTL = 1000 * 60 * 10;
    const cached = oddsRef.current[fixtureId];
    
    // ✅ si ya hay cache y está fresco, no vuelvas a pedirlo
    if (cached?.fetchedAt && Date.now() - cached.fetchedAt < ODDS_TTL) return;

    try {
      const res = await fetch(`${API_BASE}/api/odds?fixture=${encodeURIComponent(fixtureId)}`);

      // ✅ si falla HTTP, igual guarda cache con fetchedAt (si no, el TTL no sirve)
      if (!res.ok) {
        const pack = { found: false, markets: {}, fetchedAt: Date.now() };
        oddsRef.current[fixtureId] = pack;
        setOddsByFixture((prev) => ({ ...prev, [fixtureId]: pack }));
        return;
      }

      const data = await res.json();
      const pack = {
        found: !!data?.found,
        markets: data?.markets || {},
        fetchedAt: Date.now(),
      };
      // DEBUG una sola vez
      if (!window.__oddsDebugOnce) {
     window.__oddsDebugOnce = true;
     console.log("[ODDS raw data]", fixtureId, data);
     console.log("[ODDS markets keys]", fixtureId, Object.keys(data?.markets || {}));
     console.log("[ODDS markets dump]", fixtureId, data?.markets);

     }

      oddsRef.current[fixtureId] = pack;
      setOddsByFixture((prev) => ({ ...prev, [fixtureId]: pack }));
    } catch (e) {
      // ✅ en catch, también guarda fetchedAt
      const pack = { found: false, markets: {}, fetchedAt: Date.now() };
      oddsRef.current[fixtureId] = pack;
      setOddsByFixture((prev) => ({ ...prev, [fixtureId]: pack }));
    }
  },
  [API_BASE]
);

// arriba de ensureFvPack
const FVPACK_TTL = 1000 * 60 * 5; // 5 min

const ensureFvPack = useCallback(
  async (fixtureId) => {
    if (!fixtureId) return null;

    const cached = fvRef.current[fixtureId];

    if (cached && !cached.__error) return cached;

    if (cached?.__error && cached?.fetchedAt && Date.now() - cached.fetchedAt < FVPACK_TTL) {
      return null;
    }

    setFvLoadingByFixture((m) => ({ ...m, [fixtureId]: true }));
    setFvErrByFixture((m) => ({ ...m, [fixtureId]: null }));

    try {
      const res = await fetch(`${API_BASE}/api/fixture/${encodeURIComponent(fixtureId)}/fvpack`);
      if (!res.ok) throw new Error(`fvpack ${res.status}`);
      const data = await res.json();

      // DEBUG (una vez por fixture): keys del modelo para ajustar UI
      if (!window.__fvpackModelKeysOnce) window.__fvpackModelKeysOnce = {};
      if (!window.__fvpackModelKeysOnce[fixtureId]) {
        window.__fvpackModelKeysOnce[fixtureId] = true;
        const modelKeys = Object.keys((data?.model) || (data?.data?.model) || {});
        console.log("[FVPACK model keys]", fixtureId, modelKeys);
      }

      fvRef.current[fixtureId] = data;
      setFvPackByFixture((m) => ({ ...m, [fixtureId]: data }));
      return data;
    } catch (e) {
      const errPack = { __error: true, message: String(e?.message || e), fetchedAt: Date.now() };
      fvRef.current[fixtureId] = errPack;
      setFvPackByFixture((m) => ({ ...m, [fixtureId]: errPack }));
      setFvErrByFixture((m) => ({ ...m, [fixtureId]: errPack.message }));
      return null;
    } finally {
      setFvLoadingByFixture((m) => ({ ...m, [fixtureId]: false }));
    }
  },
  [API_BASE]
);


    const loadReferees = useCallback(async () => {
      
    try {
      setRefErr("");
      setRefLoading(true);
      setRefData(null);

      // MVP: usa el endpoint existente. Más adelante rankeamos con estadísticas de tarjetas.
      const params = new URLSearchParams();
      params.set("from", from);
      params.set("to", to);

      // si hay un país seleccionado, tomamos el primero
      const country = (selectedCountries || []).filter(Boolean)[0];
      if (country) params.set("country", country);

      const res = await fetch(`${API_BASE}/api/referees/cards?${params.toString()}`);
      const data = await res.json().catch(() => null);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setRefData(data);
    } catch (e) {
      setRefErr(String(e?.message || e));
    } finally {
      setRefLoading(false);
    }
  }, [from, to, selectedCountries, API_BASE]);

  function fakeOddForFixture(fx) {
    const id = getFixtureId(fx);
    const key = String(id || getHomeName(fx) + getAwayName(fx));
    let hash = 0;
    for (let i = 0; i < key.length; i++) hash = (hash + key.charCodeAt(i) * (i + 7)) % 1000;
    const base = 1.2 + (hash % 26) / 10;
    return Number(base.toFixed(2));
  }

  function buildComboSuggestion(fixturesPool, maxBoostArg) {
    if (!Array.isArray(fixturesPool) || fixturesPool.length === 0) return null;

    const picks = [];
    let product = 1;

    for (const fx of fixturesPool) {
      const odd = fakeOddForFixture(fx);
      if (product * odd > maxBoostArg * 1.35) continue;

      product *= odd;
      picks.push({ id: getFixtureId(fx), label: `${getHomeName(fx)} vs ${getAwayName(fx)}`, odd });

      if (picks.length >= 12) break;
      if (product >= maxBoostArg * 0.8) break;
    }

    if (!picks.length) return null;

    const finalOdd = Number(product.toFixed(2));
    const impliedProb = Number(((1 / finalOdd) * 100).toFixed(1));
    const reachedTarget = finalOdd >= maxBoostArg * 0.8;

    return { games: picks.length, finalOdd, target: maxBoostArg, impliedProb, reachedTarget };
  }

  const runGeneration = useCallback(
  async (mode) => {
    setParlayError("");
    setParlayResult(null);
    setFvOutput(null);
    
    try {
      if (!fixtures.length) {
        setParlayError("Genera primero partidos con el botón de arriba.");
        return;
      }

      // Pool de trabajo:
      // - auto: usa un subconjunto para velocidad
      // - selected: USA SOLO los fixtureIds seleccionados (NO rellena con otros partidos)
      const basePool = fixtures.slice(0, Math.min(60, fixtures.length));
      const selectedPool = fixtures.filter((fx) => selectedIds.includes(getFixtureId(fx)));

      const pool =
        mode === "selected"
          ? selectedPool
          : fixtures.slice(0, Math.min(28, fixtures.length));

      if (pool.length < 2) {
        setParlayError(
          mode === "selected"
            ? "Selecciona al menos 2 partidos de la lista superior."
            : "Para generar combinadas necesitas al menos 2 partidos. Amplía el rango (días) o agrega otra liga."
        );
        return;
      }
     
      const ids = pool.map(getFixtureId).filter(Boolean);

      // 1) precarga
      await Promise.all(ids.map((id) => Promise.all([ensureFvPack(id), ensureOdds(id)])));

      // 2) ahora sí valida si llegaron markets reales
      const anyMarkets = ids.some((id) => {
      const mk =
      oddsByFixture?.[id]?.markets ||
      oddsRef.current?.[id]?.markets ||
      null;
   return mk && Object.keys(mk).length > 0;
});

if (!anyMarkets) {
  setParlayError("Aún no hay cuotas reales (markets vacío). Generaré con Cuota FV por mientras.");
  // NO return -> dejamos que parlays usen FV
}

      // Referees: siempre que el plan lo permita
if (canReferees) {
  await loadReferees();
}

// ===================== MODEL BUILD =====================
const candidatesByFixture = {};

// helpers (defínelos UNA sola vez en runGeneration)
function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
function shrinkProb(p, k = 0.45) { return 0.5 + (p - 0.5) * k; } // k<1 baja confianza

function pickPenalty(label) {
  const s = String(label || "").toLowerCase();
  let p = 1;

  // penaliza "Over/Under 2.5" (muy repetido)
  if (s.includes("2.5") && (s.includes("over") || s.includes("under") || s.includes("goles"))) p *= 0.82;

  // penaliza totales en general (over/under) un poco
  if ((s.includes("over") || s.includes("under")) && !s.includes("1x") && !s.includes("x2")) p *= 0.92;

  // BTTS suele repetirse también
  if (s.includes("btts") || s.includes("both teams") || s.includes("ambos")) p *= 0.95;

  return p;
}

function probForRank(c) {
  const base = Number(c?.prob);
  const prob = Number.isFinite(base) ? base : 0.5;
  const pen = pickPenalty(c?.label || c?.pick);
  // reducimos prob solo para ranking (no para display)
  return prob * pen;
}

for (const fx of pool) {
  const id = getFixtureId(fx);
  if (!id) continue;

  // pack del endpoint fvpack (stats + modelo)
  const pack = fvPackByFixture?.[id] || fvRef.current?.[id] || null;

  // markets (odds) desde cache
  const markets =
    oddsByFixture?.[id]?.markets ||
    oddsRef.current?.[id]?.markets ||
    {};

  const rawCands = buildCandidatePicks({
    fixture: fx,
    pack: pack || {},
    markets,
  });

  // Calidad de datos: SOLO rachas (últ.5) de ambos equipos.
  // Si falta cualquiera, marcamos como parcial.
  const hasRacha = (v) => {
    const s = String(v || "").trim();
    if (!s) return false;
    // API/BD a veces devuelve "--" o "-" cuando no hay datos
    if (s === "--" || s === "-" || s.includes("--")) return false;
    // Normaliza: a veces viene con guiones/espacios ("W-W-D-L-W").
    const clean = s.toUpperCase().replace(/[^WDL]/g, "");
    return clean.length >= 3;
  };
  const dataQuality = (hasRacha(pack?.last5?.home?.form) && hasRacha(pack?.last5?.away?.form))
    ? "full"
    : "partial";
  const __qualityRank = dataQuality === "full" ? 1 : 0;

  const fixedCands = (rawCands || []).map((c) => {
    const prob = Number(c?.prob);
    const probOk = Number.isFinite(prob) ? prob : null;

    // FV odd ajustada (más conservadora)
    let fvOddAdj = c?.fvOdd;
    if (probOk != null) {
      const pAdj = clamp(shrinkProb(probOk, 0.45), 0.08, 0.90);
      fvOddAdj = 1 / pAdj;
    }

    const marketOddNum = toOdd(c?.marketOdd);
    const fvOddNum = toOdd(fvOddAdj) ?? toOdd(c?.fvOdd) ?? c?.fvOdd;

    // odd usada: mercado si existe; si no, FV
    const usedOddNum = marketOddNum ?? toOdd(c?.usedOdd) ?? fvOddNum;

    const __penalty = pickPenalty(c?.label || c?.pick);

    // Diversificación suave por tipo de pick (si no, se tiende a ir siempre a BTTS:NO)
    const labelTxt = String(c?.label || c?.pick || "").toLowerCase();
    const __typeWeight = labelTxt.includes("ambos") && labelTxt.includes("no")
      ? 0.72
      : labelTxt.includes("ambos") && (labelTxt.includes("sí") || labelTxt.includes("si"))
        ? 0.85
        : labelTxt.includes("under")
          ? 0.9
          : labelTxt.includes("over")
            ? 0.85
            : 1;

    const __probRank = (probOk != null ? probOk : 0.5) * __penalty * __typeWeight;

    return {
      ...c,
      dataQuality,
      __qualityRank,
      fvOdd: fvOddNum,
      marketOdd: marketOddNum ?? c?.marketOdd,
      usedOdd: usedOddNum,
      usedOddDisplay: usedOddNum,
      __penalty,
      __probRank,
    };
  });

  // ordena por prob "rank" (penaliza overs repetidos + diversifica) para que buildParlay/pickSafe elijan mejor
  // PRIORIDAD: datos completos (racha local+visita) -> luego probRank
  const ranked = [...fixedCands].sort((a, b) => {
    const qa = a?.__qualityRank || 0;
    const qb = b?.__qualityRank || 0;
    if (qb !== qa) return qb - qa;
    return (b.__probRank || 0) - (a.__probRank || 0);
  });
  candidatesByFixture[id] = ranked;
}

// ===================== DEBUG (DESPUÉS del loop) =====================
const firstFx = Object.keys(candidatesByFixture)[0] || null;

console.log("cand sample", Object.values(candidatesByFixture)[0]?.slice(0, 3));
console.log("cand fixtures:", Object.keys(candidatesByFixture).length);
console.log(
  "cand count total:",
  Object.values(candidatesByFixture).reduce((acc, arr) => acc + (arr?.length || 0), 0)
);

if (firstFx) {
  console.log(
    "[PARLAY] model sample",
    (candidatesByFixture[firstFx] || []).slice(0, 5).map((c) => ({
      pick: c.pick || c.label,
      prob: c.prob,
      fvOdd: c.fvOdd,
      marketOdd: c.marketOdd,
      usedOdd: c.usedOdd,
      usedOddDisplay: c.usedOddDisplay,
    }))
  );
}

// ===================== SANITIZE (números) =====================
const candidatesByFixtureSanitized = Object.fromEntries(
  Object.entries(candidatesByFixture).map(([fxId, arr]) => {
    const clean = (arr || []).map((c) => {
      const fv = toOdd(c.fvOdd);
      const mk = toOdd(c.marketOdd);
      const used = toOdd(c.usedOddDisplay) ?? toOdd(c.usedOdd) ?? mk ?? fv;

      return {
        ...c,
        fvOdd: fv ?? c.fvOdd,
        marketOdd: mk ?? c.marketOdd,
        usedOdd: used ?? c.usedOdd,
        usedOddDisplay: used ?? c.usedOddDisplay,
      };
    });

    return [fxId, clean];
  })
);

// ===================== SAFE + GIFT (AQUÍ nacen safe/giftBundle) =====================
const safe = pickSafe(candidatesByFixtureSanitized);
const giftBundle = buildGiftPickBundle(candidatesByFixtureSanitized, 1.5, 3.0, 3);

  // --- Lock gift pick to avoid contradictions in parlays (e.g., 1X vs X2 on same fixture) ---
  const giftLeg = giftBundle?.legs?.[0] || null;
  const applyGiftLock = (byFx, lockLeg) => {
    if (!lockLeg || !lockLeg.fixtureId) return byFx;
    const fx = String(lockLeg.fixtureId);
    const list = Array.isArray(byFx?.[fx]) ? byFx[fx] : null;
    if (!list) return byFx;

    // Only DC can contradict DC in our current market set
    if (lockLeg.market !== "DC") return byFx;

    const keepSelection = lockLeg.selection;
    const next = { ...byFx };
    next[fx] = list.filter((c) => !(c.market === "DC" && c.selection !== keepSelection));
    return next;
  };

  const candidatesByFixtureLocked = applyGiftLock(candidatesByFixture, giftLeg);

// ===================== TARGETS + PARLAYS =====================
const targets = [3, 5, 10, 20, 40, 100, 200].filter((t) => t <= maxBoost);
console.log("[PARLAY] targets =", targets);

// Cantidad de fixtures reales disponibles para armar parlays
const availableFixturesCount = Object.keys(candidatesByFixtureSanitized || {}).length;

// Construimos tiers siempre (3,5,10,20,50,100) para no dejar casillas vacías.
// Regla: prioriza VERDES; si para x50/x100 no alcanza, se muestra igualmente el mejor parlay
// disponible con un mensaje sugeriendo ampliar rango.
const builtParlays = targets
  .map((t) => {
    const r1 = buildParlay({
      candidatesByFixture: candidatesByFixtureSanitized,
      target: t,
      cap: maxBoost,
      hardMaxOdd: 2.5,
      mustIncludeFixtures: [],
      // Plan mensual: si hay buen pool, fuerza x10 con al menos 5 legs (se ve más “pro”).
      // Si hay poco pool, dejamos que caiga a 3 legs.
      minLegs: (t === 10 && maxBoost <= 10 && availableFixturesCount >= 7) ? 5 : 0,
    });
    console.log("[PARLAY] buildParlay target", t, "=>", r1);
    if (r1) {
      const ratio = (r1.finalOdd || 0) / (t || 1);
      return {
        ...r1,
        ratio,
        note: ratio < 1 ? `No alcanzamos x${t} con los partidos actuales. Añade 1 o 2 días más para acercarte a la cuota esperada.` : "",
      };
    }

    const r2 = buildBoostedParlayLocal({
      candidatesByFixture: candidatesByFixtureSanitized,
      target: t,
      cap: maxBoost,
    });
    console.log("[PARLAY] localParlay target", t, "=>", r2);
    if (!r2 || !Number.isFinite(r2.finalOdd)) return null;
    const ratio = (r2.finalOdd || 0) / (t || 1);
    return {
      ...r2,
      ratio,
      note: ratio < 1 ? `No alcanzamos x${t} con los partidos actuales. Añade 1 o 2 días más para acercarte a la cuota esperada.` : "",
    };
  })
  .filter(Boolean);

// Mejor parlay para fallback (por finalOdd)
const bestParlay = builtParlays
  .slice()
  .sort((a, b) => (b.finalOdd || 0) - (a.finalOdd || 0))[0];

const byTarget = new Map(builtParlays.map((p) => [p.target, p]));
const parlays = targets
  .map((t) => {
    const p = byTarget.get(t);
    if (p) return p;
    if (!bestParlay) return null;
    // Repite el mejor para completar tiers faltantes
    return {
      ...bestParlay,
      target: t,
      ratio: (bestParlay.finalOdd || 0) / (t || 1),
      note: `No alcanzamos x${t} con los partidos actuales. Añade 1 o 2 días más para acercarte a la cuota esperada.`,
      __fallback: true,
    };
  })
  .filter(Boolean);

  // ===================== VALUE LIST (usar SANITIZED) =====================
const valueList = buildValueList(candidatesByFixtureSanitized, 0.06);

console.log("parlays:", parlays);
console.log("valueList:", valueList?.length);

// si no hay nada, cortamos con error claro
if (!safe && !parlays.length) {
  setParlayError("No pudimos armar picks con stats/odds disponibles. Prueba con otro rango o liga.");
  return;
}

// output final
setFvOutput({
  mode,
  safe,
  giftBundle,
  parlays,
  valueList,
  candidatesByFixture: candidatesByFixtureSanitized
});

// panel principal muestra la primera potenciadas
// toma la más cercana al target mayor disponible
const best = parlays
  .slice()
  .sort((a, b) => (b.finalOdd || 0) - (a.finalOdd || 0))[0];

if (best) setParlayResult({ mode, ...best });

    } catch (e) {
      console.error("[FV] runGeneration error", e);
      setParlayError(String(e?.message || e));
    }
  },
  [
    fixtures,
  selectedIds,
  ensureFvPack,
  ensureOdds,
  fvPackByFixture,
  oddsByFixture,
  maxBoost,
  canReferees,
  loadReferees,
  ]
);

const handleAutoParlay = () => runGeneration("auto");
const handleSelectedParlay = () => runGeneration("selected");
// Botón gris (selected): dejamos este nombre explícito para evitar errores en build/deploy
const handleGenerateSelected = () => runGeneration("selected");
    async function handleGenerate() {
    setParlayError("");
    setParlayResult(null);

    if (!fixtures.length) {
      setParlayError("Genera primero partidos con el botón de arriba.");
      return;
    }

    if (selectedCount < 2) {
      setParlayError("Selecciona al menos 2 partidos de la lista superior.");
      return;
    }

    const pool = fixtures.filter((fx) => selectedIds.includes(getFixtureId(fx)));
    pool.map(getFixtureId).filter(Boolean).forEach((id) => ensureOdds(id));

    // Generación completa con los seleccionados como pool permitido (sin forzar que entren todos en cada parlay).
    await runGeneration("selected");
  }

  async function handleLoadFixtures(e) {
    e?.preventDefault?.();

    setErr("");
    setInfo("");
    setFixtures([]);
    setSelectedIds([]);
    setOddsByFixture({});
    oddsRef.current = {};
    setParlayResult(null);
    setParlayError("");
    setFvOutput(null);

    setRefData(null);
    setRefErr("");

    setLoading(true);

    try {
      const params = new URLSearchParams();
      params.set("from", from);
      params.set("to", to);

      const qTrim = String(q || "").trim();
      const countries = selectedCountries.filter(Boolean);

      if (countries.length === 1) {
        params.set("country", countries[0]);
        if (qTrim) params.set("q", qTrim);
      } else if (countries.length > 1) {
        if (qTrim) params.set("q", qTrim);
      } else {
        const countryEN = normalizeCountryQuery(qTrim);
        if (countryEN) params.set("country", countryEN);
        else if (qTrim) params.set("q", qTrim);
      }

        const res = await fetch(`${API_BASE}/api/fixtures?${params.toString()}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();

// DEBUG: ver forma de respuesta solo una vez por "firstId"
const itemsRaw =
  (Array.isArray(data?.items) && data.items) ||
  (Array.isArray(data?.response) && data.response) ||
  (Array.isArray(data?.fixtures) && data.fixtures) ||
  [];

const firstId = itemsRaw[0] ? getFixtureId(itemsRaw[0]) : null;

if (!window.__fixturesFirstOnce) window.__fixturesFirstOnce = {};
if (firstId && !window.__fixturesFirstOnce[firstId]) {
  window.__fixturesFirstOnce[firstId] = true;
  console.log("[FIXTURES firstId]", firstId);
  console.log("[FIXTURES raw]", data);
  console.log("[FIXTURES keys]", Object.keys(data || {}));
}

// desde aquí sigues con tu lógica normal:

      let items = itemsRaw;

      if (selectedCountries.length > 1) {
        items = items.filter((fx) => selectedCountries.includes(getCountryName(fx)));
      }

      const base = items
        .filter(isFutureFixture)
        .filter((fx) => !isYouthOrWomenOrReserve(fx));

      const filteredTop = base.filter((fx) => isAllowedCompetition(getCountryName(fx), getLeagueName(fx)));

      if (!filteredTop.length) {
        setErr("No encontramos partidos de ligas TOP para ese rango. Prueba 7–14 días y sin filtro.");
        setFixtures([]);
        return;
      }

      const sorted = [...filteredTop].sort((a, b) => {
        const da = new Date(a?.fixture?.date || a?.date || 0).getTime();
        const db = new Date(b?.fixture?.date || b?.date || 0).getTime();
        if (da !== db) return da - db;

        const pla = leaguePriority(getLeagueName(a));
        const plb = leaguePriority(getLeagueName(b));
        if (pla !== plb) return pla - plb;

        const ca = countryPriority(getCountryName(a));
        const cb = countryPriority(getCountryName(b));
        if (ca !== cb) return ca - cb;

        const ta = fixtureTimeLabel(a) || getKickoffTime(a) || "";
        const tb = fixtureTimeLabel(b) || getKickoffTime(b) || "";
        return ta.localeCompare(tb);
      });

      const LIMITED = sorted.slice(0, 140);

      setFixtures(LIMITED);
      setInfo(`API: ${itemsRaw.length} | base: ${base.length} | TOP: ${filteredTop.length} | mostrando: ${LIMITED.length}`);

      setGeneratedOk(true);
      if (okTimerRef.current) clearTimeout(okTimerRef.current);
      okTimerRef.current = setTimeout(() => setGeneratedOk(false), 2500);

      if (canReferees) await loadReferees();
    } catch (e2) {
      setErr(String(e2?.message || e2));
    } finally {
      setLoading(false);
    }
  }

  /* =========================
      VISITANTE (NO LOGUEADO)
     ========================= */
  if (!isLoggedIn) {
  return (
    <PageShell>
      <div className="space-y-4">
        <VisitorBanner />
        <Simulator bg={BG_DINERO} />
        <PriceCalculatorCard bg={BG_DINERO} />
        <VisitorEndingHero />
      </div>
    </PageShell>
  );
}

  /* =========================
      LOGUEADO (COMPARADOR)
     ========================= */
  return (
    <PageShell>
      <WelcomeProCard planInfo={planInfo} />

      {/* 1) Filtros + Generar */}
      <HudCard bg={BG_PROFILE_HUD} overlayVariant="casillas" className="mt-4" glow="gold">
        <div className="p-4 md:p-6">
          <form onSubmit={handleLoadFixtures} className="flex flex-col md:flex-row md:items-end gap-3 items-stretch">
            <div className="flex-[2]">
              <label htmlFor="qFilter" className="block text-xs text-slate-400 mb-1">
                Filtro (país / liga / equipo)
              </label>
              <input
                id="qFilter"
                name="qFilter"
                placeholder="Ej: Chile, La Liga, Colo Colo, Premier League..."
                value={q}
                onChange={(e) => setQ(e.target.value)}
                className="w-full rounded-xl bg-white/10 text-white px-3 py-2 border border-white/10"
              />
            </div>

            <div className="flex-1">
              <label htmlFor="fromDate" className="block text-xs text-slate-400 mb-1">
                Desde
              </label>
              <input
                id="fromDate"
                name="fromDate"
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="w-full rounded-xl bg-white/10 text-white px-3 py-2 border border-white/10"
              />
            </div>

            <div className="flex-1">
              <label htmlFor="toDate" className="block text-xs text-slate-400 mb-1">
                Hasta
              </label>
              <input
                id="toDate"
                name="toDate"
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="w-full rounded-xl bg-white/10 text-white px-3 py-2 border border-white/10"
              />
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-2xl font-semibold px-4 py-2 mt-4 md:mt-0 disabled:opacity-60 disabled:cursor-not-allowed transition"
                style={{
                  backgroundColor: loading
                    ? "rgba(230,196,100,0.65)"
                    : generatedOk
                    ? "rgba(16,185,129,0.55)"
                    : GOLD,
                  color: "#0f172a",
                }}
              >
                {loading ? "Generando..." : generatedOk ? "Listo" : "Generar"}
              </button>
            </div>
          </form>

          <div className="mt-3 flex flex-wrap gap-2">
            {quickCountries.map((c) => {
              const en = normalizeCountryQuery(c) || c;
              const active = selectedCountries.includes(en);

              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => toggleCountryChip(c)}
                  className="text-xs md:text-sm rounded-full px-3 py-1 border transition"
                  style={{
                    borderColor: active ? "rgba(16,185,129,0.55)" : "rgba(255,255,255,0.15)",
                    background: active ? "rgba(16,185,129,0.16)" : "rgba(255,255,255,0.05)",
                    color: "rgba(226,232,240,0.95)",
                  }}
                  title={active ? "Quitar" : "Agregar"}
                >
                  {c}
                </button>
              );
            })}
          </div>

          {err && <div className="mt-3 text-sm text-amber-300">{err}</div>}
          {!err && info && <div className="mt-3 text-xs text-slate-300/80">{info}</div>}
        </div>
      </HudCard>

      {/* 2) Partidazos */}
      <RecoWeeklyCard
        HudCard={HudCard}
        fixtures={weeklyFixtures}
        loading={weeklyLoading}
        error={weeklyErr}
        picksFromFixtures={picksFromFixturesComparator}
      />

      {/* 3) LISTADO */}
      <HudCard bg={null} bgColor="#132A23" overlayVariant="casillasSharp" className="mt-4" glow="gold">
        <section className="p-3 md:p-4">
          <div className="flex items-center justify-between px-2 py-2 text-[11px] md:text-xs text-slate-300 tracking-wide">
            <span className="uppercase">Partidos encontrados (COMPACT): {fixtures.length}</span>
            <span className="uppercase text-right">Usa “Añadir a combinada” para seleccionar y cargar cuotas.</span>
          </div>

          {fixtures.length === 0 ? (
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
              Genera partidos para verlos aquí con el formato profesional.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {fixtures.map((fx) => {
  const id = getFixtureId(fx);
  if (!id) return null;

  const fvPackRaw = fvPackByFixture[id] || fvRef.current?.[id] || null;
const fvPack = fvPackRaw && !fvPackRaw.__error ? fvPackRaw : null;

 const last5 =
  fvPack?.last5 ||
  fvPack?.data?.last5 ||
  fvPack?.stats?.last5 ||
  fvPack?.form?.last5 ||
  fvPack?.direct?.last5 ||
  null;

  const isSelected = selectedIds.includes(id);

  return (
    <FixtureCardCompact
      key={String(id)}
      fx={fx}
      isSelected={isSelected}
      fvPack={fvPack}
      last5={last5}
      onToggle={(fixtureId) => {
        toggleFixtureSelection(fixtureId);
        setParlayResult(null);
        setParlayError("");
        setFvOutput(null);
      }}
      onLoadOdds={(fixtureId) => ensureOdds(fixtureId)}
      onLoadStats={(fixtureId) => ensureFvPack(fixtureId)}
      fvLoading={!!fvLoadingByFixture[id]}
      fvErr={fvErrByFixture?.[id] || null}
    />
  );
})}

            </div>
          )}
        </section>
      </HudCard>

      {/* 4) MÓDULOS premium */}
      <section className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <FeatureCard title="Cuota de regalo" badge="Alta probabilidad" locked={!features.giftPick}>
          <div className="text-xs text-slate-300">
   Pick con mayor probabilidad de acierto. Prioriza partidos con estadísticas y datos completos. 
</div>

{fvOutput?.safe ? (
  <div className="mt-3 rounded-xl border border-white/10 bg-slate-950/30 p-3">
    <div className="text-sm font-semibold text-slate-100">{fvOutput.safe.label}</div>
    <div className="mt-1"><DataQualityBadge full={fvOutput.safe.dataQuality === "full"} /></div>
    <div className="text-xs text-slate-300 mt-1">
      {fvOutput.safe.home} vs {fvOutput.safe.away}
    </div>
    <div className="mt-2 text-xs text-slate-300">
      Prob FV: <span className="text-emerald-200 font-semibold">{Math.round(fvOutput.safe.prob * 100)}%</span>{" "}
      · Cuota FV justa: <span className="text-slate-100 font-semibold">x{fvOutput.safe.fvOdd}</span>
      {fvOutput.safe.marketOdd ? (
        <>
          {" "}· Mercado: <span className="text-slate-100 font-semibold">x{fvOutput.safe.marketOdd}</span>
        </>
      ) : null}
    </div>
  </div>
) : (
  <div className="mt-3 text-[11px] text-slate-400">Genera una combinada para que aparezca aquí.</div>
)}
        </FeatureCard>

        <FeatureCard title="Cuotas potenciadas" badge={`Hasta x${maxBoost}`} locked={!features.boosted}>
          <div className="text-xs text-slate-300">Arma una combinada automática o con partidos seleccionados.</div>

          <div className="mt-3 flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={handleAutoParlay}
              className="px-4 py-2 rounded-full text-xs font-bold"
              style={{ backgroundColor: GOLD, color: "#0f172a" }}
            >
              Generar combinada automática
            </button>

            <button
              type="button"
              onClick={handleGenerateSelected}
              className="px-4 py-2 rounded-full text-xs font-semibold border border-white/15 bg-white/5 hover:bg-white/10 transition"
            >
              Generar con seleccionados ({selectedCount})
            </button>
          </div>

          {parlayError ? <div className="mt-3 text-xs text-amber-300">{parlayError}</div> : null}

{parlayResult?.legs?.length ? (
  <div className="mt-2 space-y-1">
    {(parlayResult.legs || [])
      .filter(
        (l) =>
          l &&
          l.label &&
          l.home &&
          l.away &&
          Number(toOdd(l.usedOddDisplay) ?? toOdd(l.usedOdd)) > 1
      )
      .map((leg, idx) => {
        const oddNum = toOdd(leg.usedOddDisplay) ?? toOdd(leg.usedOdd);
        const oddToShow = oddNum && oddNum > 1 ? oddNum : null;

        return (
          <div key={`${leg.fixtureId || "fx"}-${idx}`} className="text-[11px] text-slate-300"> {" "}<span className="text-slate-500">{idx + 1}.</span>{" "}
            <span className="text-slate-100 font-semibold">{leg.label}</span>{" "}
            <span className="text-slate-500">—</span>{" "}
            {leg.home} vs {leg.away}{" "}
            {oddToShow ? (
              <>
                <span className="text-slate-500">·</span>{" "}
                <span className="text-amber-200 font-semibold">{oddToShow}</span>
              </>
            ) : null}
          </div>
        );
      })}
  </div>
) : (
  <div className="mt-3 text-[11px] text-slate-400">Genera una combinada para que aparezca aquí.</div>
)}

        </FeatureCard>

        {ENABLE_REFEREES && (
        <FeatureCard title="Árbitros tarjeteros" badge="Tarjetas" locked={!canReferees} lockText="Disponible desde Plan Anual.">
          <div className="text-xs text-slate-300">Ranking de árbitros con más tarjetas (por rango de fechas y país).</div>

          {refLoading ? <div className="mt-3 text-xs text-slate-300">Cargando árbitros…</div> : null}
          {refErr ? <div className="mt-3 text-xs text-amber-300">{refErr}</div> : null}

          {refData?.topReferees?.length ? (
  <ul className="mt-3 space-y-2">
    {refData.topReferees.slice(0, 5).map((r) => (
      <li key={r.id} className="text-slate-200">
        {r.name} — <span className="text-emerald-200 font-semibold">{r.avgCards}</span> tarjetas/partido
      </li>
    ))}
  </ul>
) : (
  <div className="mt-3 text-xs text-slate-400">
    Aún sin ranking (fixturesScanned: {refData?.fixturesScanned ?? 0}). Endpoint OK.
  </div>
)}

</FeatureCard>
        )}
        {ENABLE_SCORERS && (
        <FeatureCard
          title="Goleadores / Remates / Value"

          badge="VIP"
          locked={!(features.scorersValue || features.marketValue)}
          lockText="Disponible en planes superiores (Anual/Vitalicio)."
        >
          <div className="text-xs text-slate-300">Aquí reactivaremos los módulos avanzados (goleadores, remates, value del mercado).</div>
        </FeatureCard>
        )}

        <FeatureCard title="Parlays potenciados" badge="Parlays" locked={!features.boosted} lockText="Disponible en todos los planes.">
          <div className="text-xs text-slate-300">Parlays potenciados que genera el modelo (x3, x5, x10, x20, x40, x100 y x200 según tu plan). </div>

          {fvOutput?.parlays?.length ? (
         <div className="mt-3 space-y-3">
         {fvOutput.parlays.map((p) => (
         <div key={p.target} className="rounded-xl border border-white/10 bg-slate-950/30 p-3">
        <div className="flex items-center justify-between">
          <div className="text-sm font-semibold text-slate-100">Potenciada x{p.target}</div>
          <div className="text-xs text-slate-300">
            Final: <span className="text-amber-200 font-semibold">x{p.finalOdd}</span>{" "}
            · Partidos: {p.games}
          </div>
        </div>

        <div className="mt-2 space-y-1">
          {(p.legs || []).map((leg, idx) => {
            const oddToShow =
              (toOdd(leg.usedOddDisplay) ?? toOdd(leg.usedOdd)) > 1
                ? (toOdd(leg.usedOddDisplay) ?? toOdd(leg.usedOdd))
                : null;

            return (
              <div key={`${p.target}-${leg.fixtureId || idx}-${idx}`} className="text-[11px] text-slate-300"> {" "}<span className="text-slate-500">{idx + 1}.</span>{" "}
                <span className="text-slate-100 font-semibold">{leg.label}</span>{" "}
                <span className="text-slate-500">—</span>{" "}
                {leg.home} vs {leg.away}{" "}
                {oddToShow ? (
                  <>
                    <span className="text-slate-500">·</span>{" "}
                    <span className="text-amber-200 font-semibold">{oddToShow}</span>
                  </>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
    ))}
  </div>
) : (
  <div className="mt-3 text-[11px] text-slate-400">Genera una combinada para que aparezca aquí.</div>
)}

    </FeatureCard>
      </section>

      {/* 5) Manual Picks */}
      <ManualPicksSection />

      {/* 6) Desfase del mercado */}
      <section className="mt-6">
                <FeatureCard
                  title="Desfase del mercado"
                  badge="Value"
                  locked={!features.marketValue}
                  lockText="Disponible desde Plan Vitalicio."
                >
                  <div className="text-xs text-slate-300">
                    Picks con posible valor (cuando tu estimación FV sugiere que el mercado está pagando “de más”).
                  </div>

                  {fvOutput?.valueList?.length ? (
                    <div className="mt-3 space-y-2">
                      {fvOutput.valueList.slice(0, 8).map((v, idx) => (
                        <div
                          key={`${v.fixtureId || "fx"}-${v.label || v.pick || idx}-${idx}`}
                          className="rounded-xl border border-white/10 bg-slate-950/30 px-3 py-2"
                        >
                          <div className="text-[11px] text-slate-300"> {" "}<span className="text-slate-500">{idx + 1}.</span>{" "}
                            <span className="text-slate-100 font-semibold">{v.label || v.pick}</span>
                            {v.home && v.away ? (
                              <>
                                {" "}
                                <span className="text-slate-500">—</span> {v.home} vs {v.away}
                              </>
                            ) : null}
                          </div>

                          <div className="mt-1 text-[11px] text-slate-300">
                            FV: <span className="text-emerald-200 font-semibold">x{toOdd(v.fvOdd) ?? v.fvOdd}</span>{" "}
                            <span className="text-slate-500">·</span>{" "}
                            Mercado: <span className="text-amber-200 font-semibold">x{toOdd(v.marketOdd) ?? v.marketOdd}</span>{" "}
                            {v.valueEdge != null ? (
                              <>
                                <span className="text-slate-500">·</span>{" "}
                                Value: <span className="text-emerald-200 font-semibold">+{Math.round(Number(v.valueEdge) * 100)}%</span>
                              </>
                            ) : null}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="mt-3 text-[11px] text-slate-400">Genera una combinada para calcular value.</div>
                  )}
                </FeatureCard>
      </section>


      {/* 7) Calculadora */}
      <PriceCalculatorCard bg={BG_DINERO} />

      <div className="mt-8 text-center text-xs text-slate-500">© {new Date().getFullYear()} Factor Victoria</div>
    </PageShell>
  );
}
